console.log("Hello, world!");
console.log("This is my first TypeScript file.");
console.log("I am learning TypeScript.");
console.log("TypeScript is a superset of JavaScript.");
console.log("I can use TypeScript to write better JavaScript code.");
console.log("TypeScript has static typing, interfaces, and other features.");
console.log("I can use TypeScript to catch errors at compile time.");
console.log("I can use TypeScript to write cleaner and more maintainable code.");


console.log([1,2,3,4,5].map(x => x * x)); // This will print [1, 4, 9, 16, 25]
console.log([1,2,3,4,5].filter(x => x % 2 === 0)); // This will print [2, 4]
console.log([1,2,3,4,5].reduce((acc, x) => acc + x, 0)); // This will print 15